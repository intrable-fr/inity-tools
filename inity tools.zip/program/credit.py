import os
import time
import fade
import subprocess

credit = """
toute les database ont etais pris du serveur discord https://discord.gg/freeforreal 

rejoignez ce serveur pour avoir encore plus de database

le owner de free for real a fais ce tool (intrable)
"""

credit = fade.pinkred(credit)

print(credit)

input('appuyer sur entrée pour revenir au menu..')+ subprocess.run(['python', 'program\\database.py'])