pour lancer et utiliser le tool , veuillez lancer setup.py qui va installer les module et va lancer Main.py

veuillez ne pas critiquer mon code car je suis debutant

ce tool a pour objectif de réunir tout les tool disponible dans freeforreal et d'en faire un all in one.

pour l'utiliser , il vous faut python d'installer et il dois etre ajouter au chemin (add to path)

si vous avez le moindre soucis , créer un ticket sur discord.gg/freeforreal


pour le fivem scrapper , vous retrouverer les dump dans le files fivemScrapper.

merci de votre comprehension !! 