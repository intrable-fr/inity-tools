import os

os.system('pip install -r requirements.txt')

print("tout les requirements on bien etais installer. vous allez aller au multi tools dans 2 seconde.")

import time
time.sleep(2)
os.system('cls')
os.system('python Main.py')